// tictactoe.h
#ifndef TICTACTOE_H
#define TICTACTOE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    char board[9]; // 0-8 cells
    char winner;   // 'X', 'O', or ' '
    int turn;      // 1 = X, 2 = O
} GameState;

GameState* create_game();
void reset_game(GameState* g);
int make_move(GameState* g, int cell); // returns 1 if valid move, 0 if invalid
char check_winner(GameState* g);       // returns 'X', 'O', or ' ' 
void free_game(GameState* g);

#ifdef __cplusplus
}
#endif

#endif
