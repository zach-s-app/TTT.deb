python3 TTT.py
