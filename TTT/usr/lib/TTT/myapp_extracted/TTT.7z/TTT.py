import ctypes
import tkinter as tk
from PIL import Image, ImageTk  # for PNG handling

# Load C shared library
lib = ctypes.CDLL("./libtictactoe.so")

class GameState(ctypes.Structure):
    _fields_ = [("board", ctypes.c_char * 9),
                ("winner", ctypes.c_char),
                ("turn", ctypes.c_int)]

lib.create_game.restype = ctypes.POINTER(GameState)
lib.make_move.argtypes = [ctypes.POINTER(GameState), ctypes.c_int]
lib.make_move.restype = ctypes.c_int
lib.check_winner.argtypes = [ctypes.POINTER(GameState)]
lib.check_winner.restype = ctypes.c_char
lib.reset_game.argtypes = [ctypes.POINTER(GameState)]
lib.free_game.argtypes = [ctypes.POINTER(GameState)]

game = lib.create_game()

root = tk.Tk()
root.title("Tic Tac Toe (Big X/O + Logos + Reset)")
root.resizable(False, False)

CELL_SIZE = 100
GRID_COLOR = "black"

canvas = tk.Canvas(root, width=CELL_SIZE*3, height=CELL_SIZE*3, bg="white")
canvas.grid(row=0, column=0, columnspan=3)

label = tk.Label(root, text="Your turn!", font=("Arial", 14))
label.grid(row=1, column=0, columnspan=3, pady=5)

def draw_board():
    canvas.delete("all")
    for i in range(1, 3):
        canvas.create_line(i*CELL_SIZE, 0, i*CELL_SIZE, 3*CELL_SIZE, width=3, fill=GRID_COLOR)
        canvas.create_line(0, i*CELL_SIZE, 3*CELL_SIZE, i*CELL_SIZE, width=3, fill=GRID_COLOR)
    b = bytes(game.contents.board).decode('utf-8')
    for i, cell in enumerate(b):
        x = (i % 3) * CELL_SIZE
        y = (i // 3) * CELL_SIZE
        if cell == 'X':
            canvas.create_text(x+CELL_SIZE//2, y+CELL_SIZE//2,
                               text="X", fill="red", font=("Arial", 48, "bold"))
        elif cell == 'O':
            canvas.create_text(x+CELL_SIZE//2, y+CELL_SIZE//2,
                               text="O", fill="blue", font=("Arial", 48, "bold"))

def click(event):
    col = event.x // CELL_SIZE
    row = event.y // CELL_SIZE
    cell = row*3 + col
    if lib.make_move(game, cell):
        draw_board()
        winner_byte = lib.check_winner(game)
        winner = winner_byte.decode('utf-8')
        if winner != ' ':
            label.config(text=f"Winner: {winner}")
            canvas.unbind("<Button-1>")

def reset_game():
    lib.reset_game(game)
    draw_board()
    label.config(text="Your turn!")
    canvas.bind("<Button-1>", click)

canvas.bind("<Button-1>", click)

bottom_frame = tk.Frame(root)
bottom_frame.grid(row=2, column=0, columnspan=3, pady=5)

# --- Left: Python logo (PNG) ---
img = Image.open("python_logo.png").resize((60, 60), Image.Resampling.LANCZOS)
python_logo_img = ImageTk.PhotoImage(img)
python_canvas = tk.Canvas(bottom_frame, width=60, height=60, bg="white", highlightthickness=0)
python_canvas.pack(side="left", padx=5)
python_canvas.create_image(0, 0, anchor="nw", image=python_logo_img)

# --- Center: Reset button ---
reset_btn = tk.Button(bottom_frame, text="Reset", command=reset_game)
reset_btn.pack(side="left", padx=5)

# --- Right: C+H logo ---
ch_canvas = tk.Canvas(bottom_frame, width=50, height=50, bg="white", highlightthickness=0)
ch_canvas.pack(side="left", padx=5)
ch_canvas.create_text(25, 25, text="C", fill="blue", font=("Arial", 24, "bold"))

ch_canvas = tk.Canvas(bottom_frame, width=50, height=50, bg="white", highlightthickness=0)
ch_canvas.pack(side="left", padx=5)
ch_canvas.create_text(25, 25, text="H", fill="red", font=("Arial", 24, "bold"))
draw_board()
root.mainloop()
lib.free_game(game)

