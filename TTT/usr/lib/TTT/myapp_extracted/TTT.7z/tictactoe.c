// tictactoe.c
#include "tictactoe.h"
#include <stdlib.h>

GameState* create_game() {
    GameState* g = malloc(sizeof(GameState));
    for (int i = 0; i < 9; i++) g->board[i] = ' ';
    g->winner = ' ';
    g->turn = 1;
    return g;
}

void reset_game(GameState* g) {
    for (int i = 0; i < 9; i++) g->board[i] = ' ';
    g->winner = ' ';
    g->turn = 1;
}

int make_move(GameState* g, int cell) {
    if (cell < 0 || cell > 8) return 0;
    if (g->board[cell] != ' ') return 0;
    g->board[cell] = g->turn == 1 ? 'X' : 'O';
    g->turn = g->turn == 1 ? 2 : 1;
    g->winner = check_winner(g);
    return 1;
}

char check_winner(GameState* g) {
    int wins[8][3] = {
        {0,1,2},{3,4,5},{6,7,8}, // rows
        {0,3,6},{1,4,7},{2,5,8}, // cols
        {0,4,8},{2,4,6}          // diags
    };
    for (int i=0;i<8;i++) {
        if (g->board[wins[i][0]] != ' ' &&
            g->board[wins[i][0]] == g->board[wins[i][1]] &&
            g->board[wins[i][1]] == g->board[wins[i][2]]) {
            return g->board[wins[i][0]];
        }
    }
    return ' ';
}

void free_game(GameState* g) {
    free(g);
}
